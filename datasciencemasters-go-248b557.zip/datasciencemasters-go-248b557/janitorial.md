### Utilities, Tools, and Methods for Cleaning Up Data

#### **Tools**

* [CSV Fingerprints](http://setosa.io/blog/2014/08/03/csv-fingerprints/) makes it easy to spot irregularities in a CSV visually.
