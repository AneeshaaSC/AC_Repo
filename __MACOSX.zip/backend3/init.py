from flask import Flask, request
import detect
import os
import imp

app = Flask(__name__)

@app.route("/",methods = ['GET'])
def root():
	value = request.args.get('value')
	val = detect.response(value)
	return '%s' % val

@app.route("/train",methods = ['GET'])
def train():
	os.system("python train.py")
	detect.setup()
	return 'Training Compelte'

if __name__ == "__main__":
    app.run(host='127.0.0.1')