import sys
from detect import classify

if __name__ == '__main__':
	classify("Hello")